<?php
return array(
    '' => 'Project-Id-Version:
POT-Creation-Date:
PO-Revision-Date: 2001-11-14 17:11+0100
Last-Translator: Melle Koning <hace_x@yahoo.com>
Language-Team: <>
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: iso-8859-1
',
    'hello world' => 'bonjour le monde',
    'my first translate key' => 'Premier message correctement traduit.',
    'my second translate key' => 'Deuxième message avec login=${login} et lastCxDate=${lastCxDate} traduit',
    'Welcome ${login}, your last connection date was : ${lastCxDate}' => 'Bienvenue ${login}, votre dernière connection date de ${lastCxDate}',
);
